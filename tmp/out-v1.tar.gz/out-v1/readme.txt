1. remove duplicated sequences and asign them into A, B, and C
2. run with small reference data set and select those with template warning 

```bash
zgrep template_warning ${gtf} | grep -v NA
```
3. re-run those sequences with template warning with full reference data set,
find out those still with template warning tag which need manually check


Time statistics

thread number : 5 

A: 252 alleles
B: 524 alleles
C: 224 alleles

A full : wall 556 seconds, cpu 7.2s/allele
A small : wall 43 seconds, cpu 0.5s/allele 
B full : wall 2109 seconds, cpu 9.1s/allele
B small : wall 273 seconds, cpu 1.2s/allele
C full : wall :383 seconds, cpu 5.2s/allele
C small: wall 20 seconds, cpu 0.3s/allele


Run:

# split test.fa.gz into 
#####test.HLA-A.fa.gz
#####test.HLA-B.fa.gz
#####test.HLA-C.fa.gz


#then run

for s in HLA-A HLA-B HLA-C
do
  fa=test.${s}.fa.gz
  # for small ref data set
  ref=Data-2025Mar11.${s}-small;out=test.${s}-small
  time bash tools/immuannot.sh -c ${fa} -r ${ref} -o ${out} -t 5
  # for full A,B,C ref
  ref=Data-2025Mar12.${s};out=test.${s}
  time bash tools/immuannot.sh -c ${fa} -r ${ref} -o ${out} -t 5
done

